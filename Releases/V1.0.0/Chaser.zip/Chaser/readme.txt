=== Chaser ===
Author URI: https://Itmrk.com
Theme URI: https://itmrk.com
Contributors: Jerry James
Tags: itmrk 
Requires at least: 5.2
Tested up to: 5.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Chaser is a clean and simple WordPress theme with beautiful typography and subtle colors.

== Description ==

Chaser is a clean and simple WordPress theme with beautiful typography and subtle colors.
This tean is derived from Chaser theam.
And Chaser is based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc.


== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in Chaser in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.
4. For a guide on how to customize this theme, descripition shall be providded in each section.
5. Navigate to Appearance > Customize in your admin panel and customize to taste.

== Changelog ==

= 1.0.0 - 15-Nov-2020 =
* Initial Release
* Derived from wellington 1.9.1

== Copyright ==

Chaser WordPress Theme, Copyright 2020 itmrk.com
Chaser is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

== Ressources ==

Chaser bundles the following third-party resources:

1. Genericons Icon Font - http://genericons.com
License: Distributed under the terms of the GPLv2 (https://www.gnu.org/licenses/gpl-2.0.html)
Copyright: 2015 Automattic, Inc., https://automattic.com/

2. Underscores - http://underscores.me/
License: Distributed under the terms of the GPLv2 (https://www.gnu.org/licenses/gpl-2.0.html)
Copyright: 2012-2015 Automattic, Inc., https://automattic.com/

3. normalize.css - http://necolas.github.io/normalize.css/
License: Distributed under the terms of the MIT License (http://opensource.org/licenses/MIT)
Copyright: 2012-2015 Nicolas Gallagher and Jonathan Neal

4. FlexSlider - https://github.com/woothemes/FlexSlider
License: Distributed under the terms of the GPLv2 (https://www.gnu.org/licenses/gpl-2.0.html)
Copyright: 2015 WooThemes, http://www.woothemes.com

5. HTML5 Shiv - https://github.com/aFarkas/html5shiv
License: Distributed under the terms of the GPLv2 (https://www.gnu.org/licenses/gpl-2.0.html)
Copyright: 2015 @afarkas @jdalton @jon_neal @rem

6. Gudea Font - https://www.google.com/fonts/specimen/Gudea
License: Distributed under the terms of the SIL Open Font License (http://scripts.sil.org/OFL)
Copyright: Agustina Mingote

7. Magra Font - https://www.google.com/fonts/specimen/Magra
License: Distributed under the terms of the SIL Open Font License (http://scripts.sil.org/OFL)
Copyright: FontFuror

8. Images used in screenshot.jpg are all from Pixabay - http://pixabay.com

Image 1: https://pixabay.com/en/bottom-bracket-gear-mountain-bike-1204870/
License: Distributed under the terms of the CC0 License (https://creativecommons.org/publicdomain/zero/1.0/)
Copyright: 2015 Stefan Schweihofer (https://pixabay.com/en/users/stux-12364/)


